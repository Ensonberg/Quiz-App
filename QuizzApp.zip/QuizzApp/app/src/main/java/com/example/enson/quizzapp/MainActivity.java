package com.example.enson.quizzapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int score=0;
    Button buttonSubmit;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnSubmit = (Button) findViewById(R.id.button_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){




                int score = 0;
                if (((RadioButton)findViewById(R.id.yes_radio_one_2)).isChecked()) {score++;}
                if (((RadioButton)findViewById(R.id.yes_radio_two_3)).isChecked()) {score++;}
                if (((RadioButton)findViewById(R.id.yes_radio_three_3)).isChecked()) {score++;}
                if (((RadioButton) findViewById(R.id.yes_radio_four_4)).isChecked()){score++;}
                if (((RadioButton) findViewById(R.id.yes_radio_five_4)).isChecked()){score++;}
                if (((RadioButton) findViewById(R.id.yes_radio_six_3)).isChecked()){score++;}
                if (((RadioButton) findViewById(R.id.yes_radio_seven_2)).isChecked()) {score++;}
                if(((RadioButton) findViewById(R.id.yes_radio_eight_1)).isChecked()){score++;}
                if(((RadioButton) findViewById(R.id.yes_radio_nine_4)).isChecked()){score++;}
                if(((RadioButton) findViewById(R.id.yes_radio_ten_3)).isChecked()){score++;}

                displayResult(score);
            }

        });}
    private void displayResult(int score) {
        EditText nameField=(EditText)findViewById(R.id.edit_text);
        String name =nameField.getText().toString();
        String message = name+"\n You scored " + score;
        message += " out of 10";
        message += "\nWell done!";
        //Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        //toast.setGravity(Gravity.CENTER, 0 , 0);
        //toast.show();
        TextView text1 =(TextView) findViewById(R.id.score_text_view);
        text1.setText(message);



    }


}